<?php 
include('header.html');
REQUIRE_ONCE ('dbCreation.php');
INCLUDE  ('index.html');
?>



<?php
include ('footer.php');
?>